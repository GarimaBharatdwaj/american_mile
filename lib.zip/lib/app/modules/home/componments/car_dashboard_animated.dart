import '../../../../common_lib.dart';

class CarDashboardAnimated extends StatelessWidget {
  const CarDashboardAnimated({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(),
    );
  }
}
