import 'package:get/get.dart';

class ManualVehicalDetailsController extends GetxController {
  //TODO: Implement ManualVehicalDetailsController

  final count = 0.obs;
  @override
  void onInit() {
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }

  List<String> yaerList = [
    "2024",
    "2023",
    "2022",
    "2021",
    "2020",
    "2019",
    "2018",
    "2017",
    "2016",
    "2015",
    "2014",
    "2013",
    "2012",
    "2011",
    "Older",
  ];
  List<String> makeList = [
    "Acura",
    "Alfa Romeo",
    "Aston Martin",
    "Audi",
    "Bentley",
    "BMW",
    "Buick",
    "Cadillac",
    "Chevrolet",
    "Chrysler",
    "Dodge",
    "Ferrari",
  ];
  List<String> modelList = [
    "DB11",
    "DBS",
    "Vantage",
  ];

  void increment() => count.value++;
}
