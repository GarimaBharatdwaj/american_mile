import '../../../../common_lib.dart';

class AutoDetails extends StatelessWidget {
  const AutoDetails({super.key});

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
