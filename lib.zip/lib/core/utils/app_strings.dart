class AppStrings {
  static String login = "Login";
  static String insuranceDashboard = "Insurance Dashboard";
  static String myProfile = "My Profile";
}
